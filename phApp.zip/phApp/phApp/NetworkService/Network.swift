//
//  Network.swift
//  phApp
//
//  Created by Анна on 03.06.2020.
//  Copyright © 2020 anna. All rights reserved.
//

import Foundation
import Alamofire
enum API {
    static let baseURL = "https://anna-course-project.herokuapp.com/"
    static func url(str: String) -> String{
        let str = API.self.baseURL + str
        return str
    }
    
}

class NetworkService{
    private init() {}
    static let shared = NetworkService()
    
    func signInUser(parameters:[String:String],completion: @escaping (Result<User,NetworkError>)->Void) {
        AF.request(API.url(str: "authenticate"), method: .post, parameters: parameters, encoding: JSONEncoding.default).responseData { (response) in
            switch response.result {
            case .success(let userFromBack):
                do {
                    let user = try JSONDecoder().decode(User.self, from: userFromBack)
                    globalMainUser = user
                    globalTOken = globalMainUser?.token
                    completion(.success(user))
                } catch {
                    completion(.failure(NetworkError.authenticationError))
                }
            case .failure(_):
                if let httpStatusCode = response.response?.statusCode {
                    switch httpStatusCode {
                    case 401:
                        completion(.failure(NetworkError.noSuchUser))
                    default:
                        break
                    }
                } else {
                    completion(.failure(NetworkError.badRequest))
                }
            }
        }
    }
    
    func changePassword(password: String,completion: @escaping(Result<User,NetworkError>)->Void) {
        guard let user =  globalMainUser else {return}
        guard let token = user.token else {return}
        guard let id = user.userId else {return}
        let headers: HTTPHeaders =  ["Authorization": "Bearer \(token)", "Content-Type":"application/json"]
        let parameters = ["password":password]
         AF.request(API.url(str: "\(id)/password"),method: .patch, parameters: parameters, encoding: JSONEncoding.default,  headers: headers).validate(statusCode: 200...201).responseData { (response) in
             switch response.result {
             case .success(let data):
                  do {
                     let user = try! JSONDecoder().decode(User.self, from: data)
                     globalPassword = password
                     completion(.success(user))
                 } catch {
                    completion(.failure(NetworkError.changeError))
                 }
             case .failure(_):
                completion(.failure(NetworkError.changeError))
             }
         }
     }
     
    func changeUser(user:User, completion: @escaping(Result<User,NetworkError>)->Void) {
        guard let myUser =  globalMainUser else {return}
        guard let id = myUser.userId else {return}
        guard let token = myUser.token else {return}
        let headers: HTTPHeaders =  ["Authorization": "Bearer \(token)", "Content-Type":"application/json"]
        let fn = user.firstName ?? ""
        let em = user.email ?? ""
        let ln = user.lastName ?? ""
        let parameters = ["email":em,"firstName":fn,"lastName":ln] as [String : Any]
        print(parameters)
        AF.request(API.url(str: "\(id)/profile/credentials"),method: .patch, parameters: parameters, encoding: JSONEncoding.default,  headers: headers).validate(statusCode: 200...201).responseData { (response) in
            switch response.result {
            case .success(let patchData):
                do {
                    let user = try JSONDecoder().decode(User.self, from: patchData)
                    globalMainUser = user
                    completion(.success(user))
                } catch {
                    completion(.failure(NetworkError.changeError))
                }
            case .failure(_):
                completion(.failure(NetworkError.changeError))
            }
        }
    }
    
    func getFacePhMeasures(completion: @escaping(Result<[Measure],NetworkError>)->Void) {
        guard let myUser =  globalMainUser else {return}
        guard let id = myUser.userId else {return}
        guard let token = myUser.token else {return}
        let headers: HTTPHeaders =  ["Authorization": "Bearer \(token)"]
        AF.request(API.url(str: "\(id)/profile"),headers: headers).validate(statusCode: 200..<201).responseData { (response) in
            switch response.result {
            case .success(let userData):
                do {
                    let objectUser = try JSONSerialization.jsonObject(with: userData, options: []) as! [String:Any]
                   
                    let faceApparatsDict = objectUser["faceApparats"] as! [[String:Any]]
                    let phFaceMeasuresDict = faceApparatsDict[0]["phFaceMeasures"] as! [[String:Any]]
                    var emptyArr = [Measure]()
                    for i in phFaceMeasuresDict {
                        let id = i["measureId"] as! Int
                        let measureDate = i["measureDate"] as! String
                        let phFaceMeaure = i["phFaceMeasure"] as! Double
                        let measure = Measure(measureId: id, measureDate: measureDate, phFaceMeasure: phFaceMeaure)
                        emptyArr.append(measure)
                    }
                    DispatchQueue.main.async {
                        completion(.success(emptyArr))
                    }
                    
                } catch  {
                    completion(.failure(NetworkError.measuresFailes))
                }
                
            case .failure(_):
                completion(.failure(NetworkError.measuresFailes))
            }
        }
    }
    
    func getSalivaPhMeasures(completion: @escaping(Result<[MeasureSaliva],NetworkError>)->Void) {
           guard let myUser =  globalMainUser else {return}
           guard let id = myUser.userId else {return}
           guard let token = myUser.token else {return}
           let headers: HTTPHeaders =  ["Authorization": "Bearer \(token)"]
           AF.request(API.url(str: "\(id)/profile"),headers: headers).validate(statusCode: 200..<201).responseData { (response) in
               switch response.result {
               case .success(let userData):
                   do {
                       let objectUser = try JSONSerialization.jsonObject(with: userData, options: []) as! [String:Any]
                      
                       let faceApparatsDict = objectUser["salivaApparats"] as! [[String:Any]]
                    
                      let phFaceMeasuresDict = faceApparatsDict[0]["phSalivaMeasures"] as! [[String:Any]]
                       var emptyArr = [MeasureSaliva]()
                       for i in phFaceMeasuresDict {
                           let id = i["measureId"] as! Int
                           let measureDate = i["measureDate"] as! String
                           let phFaceMeaure = i["phSalivaMeasure"] as! Double
                        let measure = MeasureSaliva(measureId: id, measureDate: measureDate, phSalivaMeasure: phFaceMeaure)
                           emptyArr.append(measure)
                       }
                       DispatchQueue.main.async {
                           completion(.success(emptyArr))
                       }
                       
                   } catch  {
                       completion(.failure(NetworkError.measuresFailes))
                   }
                   
               case .failure(_):
                   completion(.failure(NetworkError.measuresFailes))
               }
           }
       }
        
     
    
    func checkFaceAparat(completion: @escaping(Result<Bool,NetworkError>)->Void) {
        guard let myUser =  globalMainUser else {return}
        guard let id = myUser.userId else {return}
        guard let token = myUser.token else {return}
        let headers: HTTPHeaders =  ["Authorization": "Bearer \(token)"]
        AF.request(API.url(str: "\(id)/profile"),headers: headers).validate(statusCode: 200..<201).responseData { (response) in
                switch response.result {
                case .success(let userData):
                    do {
                        guard  let objectUser = try JSONSerialization.jsonObject(with: userData, options: []) as? [String:Any] else {
                            completion(.success(false))
                            return
                        }
                       
                        guard let faceApparatsDict = objectUser["faceApparats"] as? [[String:Any]] else {
                             completion(.success(false))
                            return
                        }
                        
                        guard faceApparatsDict.count>=1 else {
                            completion(.success(false))
                            return
                        }
                        guard let arr = faceApparatsDict[0] as? [String:Any] else {
                            completion(.success(false))
                            return
                        }
                            
                        guard let apparatId = arr["apparatId"] as? Int else {
                            completion(.success(false))
                            return
                        }
                        DispatchQueue.main.async {
                            completion(.success(true))
                        }
                        
                    } catch  {
                        completion(.failure(NetworkError.errorFaceAparat))
                    }
                    
                case .failure(_):
                    completion(.failure(NetworkError.errorFaceAparat))
                }
            }
        }
    
    func checkSalivaAparat(completion: @escaping(Result<Bool,NetworkError>)->Void) {
           guard let myUser =  globalMainUser else {return}
           guard let id = myUser.userId else {return}
           guard let token = myUser.token else {return}
           let headers: HTTPHeaders =  ["Authorization": "Bearer \(token)"]
           AF.request(API.url(str: "\(id)/profile"),headers: headers).validate(statusCode: 200..<201).responseData { (response) in
                   switch response.result {
                   case .success(let userData):
                       do {
                           guard  let objectUser = try JSONSerialization.jsonObject(with: userData, options: []) as? [String:Any] else {
                               completion(.success(false))
                               return
                           }
                          
                           guard let faceApparatsDict = objectUser["salivaApparats"] as? [[String:Any]] else {
                                completion(.success(false))
                               return
                           }
                           
                           guard faceApparatsDict.count>=1 else {
                               completion(.success(false))
                               return
                           }
                           guard let arr = faceApparatsDict[0] as? [String:Any] else {
                               completion(.success(false))
                               return
                           }
                               
                           guard let apparatId = arr["apparatId"] as? Int else {
                               completion(.success(false))
                               return
                           }
                           DispatchQueue.main.async {
                               completion(.success(true))
                           }
                           
                       } catch  {
                           completion(.failure(NetworkError.errorSalivaAparat))
                       }
                       
                   case .failure(_):
                       completion(.failure(NetworkError.errorSalivaAparat))
                   }
               }
           }
    
    
    
}
     
     
     


