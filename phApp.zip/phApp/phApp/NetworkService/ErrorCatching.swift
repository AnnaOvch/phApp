//
//  ErrorCatching.swift
//  phApp
//
//  Created by Анна on 03.06.2020.
//  Copyright © 2020 anna. All rights reserved.
//

import Foundation

enum NetworkError: Error {
    case noSuchUser
    case authenticationError
    case badRequest
    case changeError
    case measuresFailes
    case errorFaceAparat
    case errorSalivaAparat
    var description: String {
        switch self {
        case .noSuchUser:
            return "There is no such registered user"
        case .authenticationError:
            return "There is an error in authentication"
        case .badRequest:
            return "Check connection with Internet and server"
        case .changeError:
            return "There is an eror in chhanging profile"
        case .measuresFailes:
            return "Measures can not be loaded"
        case .errorFaceAparat:
            return "An error in getting face aparat"
        case .errorSalivaAparat:
            return "An error in getting saliva aparat"
        }
    }
    
}
