//
//  Validation.swift
//  phApp
//
//  Created by Анна on 03.06.2020.
//  Copyright © 2020 anna. All rights reserved.
//

import Foundation

protocol Validatings {
    func validateEmail(candidate: String) -> Bool
    func validatePassword(candidate: String) -> Bool
}
extension Validatings {
     func validateEmail(candidate: String) -> Bool {
        let emailRegex = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
           return NSPredicate(format: "SELF MATCHES %@", emailRegex).evaluate(with: candidate)
       }
       func validatePassword(candidate: String) -> Bool {
           let passwordRegex = "^(?=.*[A-Za-z])(?=.*\\d)[A-Za-z\\d]{6,}$"
           
           return NSPredicate(format: "SELF MATCHES %@", passwordRegex).evaluate(with: candidate)
           
       }
    
    func validateName(candidate: String)->Bool {
        if candidate.isEmpty || candidate.count==1 {
            return false
        }
        return true
    }
}
