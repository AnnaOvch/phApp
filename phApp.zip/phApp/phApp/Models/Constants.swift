//
//  Constants.swift
//  phApp
//
//  Created by Анна on 03.06.2020.
//  Copyright © 2020 anna. All rights reserved.
//

import Foundation

var globalPassword: String?
var globalMainUser: User?
var globalTOken: String?
var globalLinePlotData: [Measure]?
var globalLinePlotDataSaliva: [MeasureSaliva]?
var globalFaceAparat: Bool?
var globalSalivaAparat: Bool?

