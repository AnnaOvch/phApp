//
//  User.swift
//  phApp
//
//  Created by Анна on 03.06.2020.
//  Copyright © 2020 anna. All rights reserved.
//

import Foundation
struct User: Codable {
    var userId: Int?
    var email: String?
    var firstName: String?
    var lastName: String?
    var token: String?
    var birthDate: String?
    var dateJoined: String?
    var roles:[String]?
    var password: String?
   
//
//    var password: String?
//    var tokenExpirationDate: String?
//    var roles: [String]?
//    var enabled: Bool?
//    var username: String?
//    var accountNonExpired:Bool?
//    var accountNonLocked: Bool?
//    var credentialsNonExpired:Bool?
   // var authorities: [String]?
}

