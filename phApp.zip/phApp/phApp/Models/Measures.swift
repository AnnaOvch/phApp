//
//  Measures.swift
//  phApp
//
//  Created by Анна on 05.06.2020.
//  Copyright © 2020 anna. All rights reserved.
//
import Foundation

struct Measure {
    var measureId: Int
    var measureDate: String
    var phFaceMeasure: Double
    var dateFormat: Date?
}

struct MeasureSaliva {
    var measureId: Int
    var measureDate: String
    var phSalivaMeasure: Double
    var dateFormat: Date?
}

