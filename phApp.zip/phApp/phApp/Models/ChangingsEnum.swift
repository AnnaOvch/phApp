//
//  ChangingsEnum.swift
//  phApp
//
//  Created by Анна on 04.06.2020.
//  Copyright © 2020 anna. All rights reserved.
//

import Foundation

enum Changings: String {
    case password = "password"
    case email = "email"
    case lastName = "last name"
    case firstName = "first name"
    
    var headers: (String,String) {
        switch self {
        case .password:
            return ("Enter old password","Enter new password")
        case .email:
            return ("Your old email","Enter new email")
        case .firstName:
            return ("Your old first name","Enter new first name")
        case .lastName:
            return ("Your old last name","Enter new last name")
        
        }
    }
}
