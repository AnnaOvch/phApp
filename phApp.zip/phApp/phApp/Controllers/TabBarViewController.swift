//
//  TabBarViewController.swift
//  phApp
//
//  Created by Анна on 03.06.2020.
//  Copyright © 2020 anna. All rights reserved.
//

import UIKit

class TabBarViewController: UITabBarController {

    override func viewDidLoad() {
        super.viewDidLoad()
        print("ViewDidLoad tab bar")

        NetworkService.shared.checkFaceAparat { (result) in
            switch result {
            case .success(let boolValue):
                globalFaceAparat = boolValue
                print("global face ap \(globalFaceAparat)")
            case .failure(let error):
                globalFaceAparat = false
                
            }
        }
        
        NetworkService.shared.checkSalivaAparat { (result) in
            switch result {
            case .success(let boolValue):
                globalSalivaAparat = boolValue
            case .failure(let error):
                globalSalivaAparat = false
            }
        }
        
     
    }
    

   

}
extension TabBarViewController: StoryboardLoadable{
    static var storyboardName: String {
        return "TabBar"
    }
    
    
}
