//
//  ProfileTableViewController.swift
//  phApp
//
//  Created by Анна on 03.06.2020.
//  Copyright © 2020 anna. All rights reserved.
//

import UIKit

class ProfileTableViewController: UITableViewController {
    
    @IBOutlet weak var emailLabel: UILabel!
    @IBOutlet weak var firstNameLabel: UILabel!
    @IBOutlet weak var lastNameLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.allowsSelection = false
        tableView.backgroundColor = hexStringToUIColor(hex: "#f6dddd")
        setUpLabels()

    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        setUpLabels()
    }

    @IBAction func changePassword(_ sender: Any) {
        let vc = UIStoryboard(name: "Profile", bundle: nil).instantiateViewController(identifier: "changeVC") as! ChangeProfileTableViewController
        vc.editingThing = Changings.password
        vc.firstHeader = Changings.password.headers.0
        vc.secondHeader = Changings.password.headers.1
        vc.userBeforeChanging = globalMainUser
        navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func logOut(_ sender: Any) {
        self.dismiss(animated: true) {
            globalPassword = nil
            globalMainUser = nil
            globalTOken = nil
        }
    }
    
    override func tableView(_ tableView: UITableView, accessoryButtonTappedForRowWith indexPath: IndexPath) {
        let vc = UIStoryboard(name: "Profile", bundle: nil).instantiateViewController(identifier: "changeVC") as! ChangeProfileTableViewController
        switch indexPath.section  {
        case 0:
            vc.editingThing = Changings.email
            vc.firstHeader = Changings.email.headers.0
            vc.secondHeader = Changings.email.headers.1
            
        case 1:
            vc.editingThing = Changings.firstName
            vc.firstHeader = Changings.firstName.headers.0
            vc.secondHeader = Changings.firstName.headers.1
        case 2:
            vc.editingThing = Changings.lastName
            vc.firstHeader = Changings.lastName.headers.0
            vc.secondHeader = Changings.lastName.headers.1
        default:
            break
        }
        vc.userBeforeChanging = globalMainUser
        navigationController?.pushViewController(vc, animated: true)
        
    }
    
 }

extension ProfileTableViewController {
    
    func setUpLabels() {
         guard let mainuser = globalMainUser else {return}
        emailLabel.text = globalMainUser?.email
        firstNameLabel.text = mainuser.firstName ?? "No first name"
        lastNameLabel.text = mainuser.lastName ?? "No last name"
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let vc = segue.destination as! ChangeProfileTableViewController
        
    }
    

    func hexStringToUIColor (hex:String) -> UIColor {
        var cString:String = hex.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()

        if (cString.hasPrefix("#")) {
            cString.remove(at: cString.startIndex)
        }

        if ((cString.count) != 6) {
            return UIColor.gray
        }

        var rgbValue:UInt64 = 0
        Scanner(string: cString).scanHexInt64(&rgbValue)

        return UIColor(
            red: CGFloat((rgbValue & 0xFF0000) >> 16) / 255.0,
            green: CGFloat((rgbValue & 0x00FF00) >> 8) / 255.0,
            blue: CGFloat(rgbValue & 0x0000FF) / 255.0,
            alpha: CGFloat(1.0)
        )
    }
}
