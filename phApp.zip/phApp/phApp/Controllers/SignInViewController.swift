//
//  SignInViewController.swift
//  phApp
//
//  Created by Анна on 03.06.2020.
//  Copyright © 2020 anna. All rights reserved.
//

import UIKit

class SignInViewController: UIViewController {
    
    @IBOutlet weak var emailTextField: UITextField! {
        didSet {
            emailTextField.layer.cornerRadius = emailTextField.frame.height/3
            let paddingView = UIView(frame: CGRect(x: 0, y: 0, width: 10, height: emailTextField.frame.size.height))
            emailTextField.leftView = paddingView
            emailTextField.leftViewMode = .always
        }
    }
    
    @IBOutlet weak var passwordTextField: UITextField! {
        didSet {
            passwordTextField.layer.cornerRadius = passwordTextField.frame.height/3
            let paddingView = UIView(frame: CGRect(x: 0, y: 0, width: 10, height: passwordTextField.frame.size.height))
            passwordTextField.leftView = paddingView
            passwordTextField.leftViewMode = .always
        }
    }
    
    let activityView = UIActivityIndicatorView(style: .medium)
    
    override func viewDidLoad() {
        super.viewDidLoad()
        emailTextField.delegate = self
        passwordTextField.delegate = self

    }
    
    @IBAction func signUpButton(_ sender: Any) {
        guard let credits = checkLogIn() else { return }
       showActivityIndicatory(actView: activityView)
        NetworkService.shared.signInUser(parameters: credits) { [weak self] (result) in
            switch result {
            case .success(let user):
                if let self = self {
                    self.hideActivityIndicator(actView: self.activityView)
                }
                globalPassword = credits["password"]
                
                
                
                
                
                let vc = TabBarViewController.instance()
                vc.modalPresentationStyle = .fullScreen
                self?.present(vc, animated: true)
            case .failure(let error):
                if let self = self {
                    self.hideActivityIndicator(actView: self.activityView)
                }
                self?.showAlert(alertText: error.description, alertAction: "ok", handler: nil)
            }
            
        }
    }
    
    

}
extension SignInViewController: Validatings {
    func checkLogIn() -> [String:String]? {
        if emailTextField.text!.isEmpty {
            showAlert(alertText : "Please enter email", alertAction : "ок", handler: nil)
        } else if  passwordTextField.text!.isEmpty {
            showAlert(alertText : "Please enter password", alertAction : "ок", handler: nil)
        } else {
            var text = ""
            let validatedEmailBool = validateEmail(candidate:  emailTextField.text!)
            let validatedPasswordBool = validatePassword(candidate: passwordTextField.text!)
            if  validatedEmailBool && validatedPasswordBool {
                globalPassword = passwordTextField.text!
                return ["email":emailTextField.text!,"password":passwordTextField.text!]
            } else {
                text = !validatedEmailBool ? "Incorrect email" : "Incorrect password"
                self.showAlert(alertText: text, alertAction: "ok", handler: nil)
            }
        }
        return nil
    }
}
extension SignInViewController: UITextFieldDelegate {
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
}
