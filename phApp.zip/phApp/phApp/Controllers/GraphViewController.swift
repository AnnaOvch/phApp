//
//  GraphViewController.swift
//  phApp
//
//  Created by Анна on 04.06.2020.
//  Copyright © 2020 anna. All rights reserved.
//

import UIKit
import ScrollableGraphView

class GraphViewController: UIViewController {
    
    var linePlotData = [5,5,5,5,5,5,5.0]
    //var linePlotData =  [Double]() c
    var datesData = [String]()
   // let pickerData = ["Year","Month","Week"]
    let pickerData = ["Enjoy your pH"]
    var myDatesForPlot1 = [String]()
    var myDatesForPlot2 = [String]()
    
    
    var facePhs = [Double]()
    var salivaPhs = [Double]()
    
    @IBOutlet weak var viewForGraph: UIView!
    @IBOutlet weak var periodPickerView: UIPickerView!
    @IBOutlet weak var segmentFaceSaliva: UISegmentedControl!

    override func viewDidLoad() {
        super.viewDidLoad()
        
        if let faceAparat = globalFaceAparat, faceAparat == true {
            getFaceMeasFromBack()
        } else {
            let message = UILabel()
            message.text = "Unfortunately you do not have face apparat"
            message.translatesAutoresizingMaskIntoConstraints = false
            message.lineBreakMode = .byWordWrapping
            message.numberOfLines = 0
            message.textAlignment = .center

            self.view.addSubview(message)

            message.widthAnchor.constraint(equalTo: view.widthAnchor).isActive = true
            message.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
            message.centerYAnchor.constraint(equalTo: view.centerYAnchor).isActive = true
        }
//
//        if let salivaAparat = globalSalivaAparat, salivaAparat == true {
//                  getSalivaMeasFromBack()
//              }
        
       // getSalivaMeasFromBack()
        //setUpGraph()
        self.periodPickerView.delegate = self
        self.periodPickerView.dataSource = self

        periodPickerView.selectRow(0, inComponent: 0, animated: true)
        
        
    }
    
    @IBAction func segmentChange(_ sender: Any) {
        print("cgange \(segmentFaceSaliva.selectedSegmentIndex)")
        //periodPickerView.selectRow(0, inComponent: 0, animated: true)
        switch segmentFaceSaliva.selectedSegmentIndex {
        case 0:
            if let faceAparat = globalFaceAparat, faceAparat == true {
                linePlotData = facePhs
            } else {
                let message = UILabel()
                           message.text = "Unfortunately you do not have face apparat"
                           message.translatesAutoresizingMaskIntoConstraints = false
                           message.lineBreakMode = .byWordWrapping
                           message.numberOfLines = 0
                           message.textAlignment = .center

                           self.view.addSubview(message)

                           message.widthAnchor.constraint(equalTo: view.widthAnchor).isActive = true
                           message.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
                           message.centerYAnchor.constraint(equalTo: view.centerYAnchor).isActive = true
            }
            
            
        case 1:
            if let salivaAparat = globalSalivaAparat, salivaAparat == true {
                getSalivaMeasFromBack()
                linePlotData = salivaPhs
            } else {
                let message = UILabel()
                message.text = "Unfortunately you do not have face apparat"
                message.translatesAutoresizingMaskIntoConstraints = false
                message.lineBreakMode = .byWordWrapping
                message.numberOfLines = 0
                message.textAlignment = .center
                
                self.view.addSubview(message)
                
                message.widthAnchor.constraint(equalTo: view.widthAnchor).isActive = true
                message.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
                message.centerYAnchor.constraint(equalTo: view.centerYAnchor).isActive = true
            }
        default:
            break
        }
        setUpGraph()
        
   }
    
    override func viewWillAppear(_ animated: Bool) {
        print("will appear")
    }
    
    
}
extension GraphViewController : ScrollableGraphViewDataSource {
   
    
    func setUpGraph() {
        let graphView = ScrollableGraphView(frame: CGRect(x: viewForGraph.frame.origin.x, y: viewForGraph.frame.origin.y, width: viewForGraph.frame.width, height: viewForGraph.frame.height), dataSource: self)
        graphView.shouldAnimateOnAdapt = true

          let linePlot = LinePlot(identifier: "line")
          linePlot.adaptAnimationType = ScrollableGraphViewAnimationType.elastic
          linePlot.lineStyle = ScrollableGraphViewLineStyle.smooth
          linePlot.lineWidth = 5.0
          linePlot.lineColor = hexStringToUIColor(hex: "#ffb3ba")
          linePlot.shouldFill = true
          linePlot.fillColor = hexStringToUIColor(hex: "#fce7e7")
          
          
          let dotPlot = DotPlot(identifier: "dotLine")
          dotPlot.dataPointType = ScrollableGraphViewDataPointType.circle
          dotPlot.dataPointSize = 5
          dotPlot.dataPointFillColor = hexStringToUIColor(hex:"#7ea6f8")
          
          let referenceLines = ReferenceLines()
          referenceLines.referenceLineColor = hexStringToUIColor(hex: "#922e74")
          referenceLines.referenceLineLabelColor = hexStringToUIColor(hex: "#922e74")
        
          graphView.rangeMin = 3.0
          graphView.rangeMax = 7.0
          graphView.dataPointSpacing = 40.0
          //graphView.shouldAdaptRange = true
          graphView.addPlot(plot: linePlot)
          graphView.addPlot(plot: dotPlot)
          
          graphView.addReferenceLines(referenceLines: referenceLines)
          self.view.addSubview(graphView)
    }
    func value(forPlot plot: Plot, atIndex pointIndex: Int) -> Double {
              switch(plot.identifier) {
              case "line":
                  return Double(linePlotData[pointIndex])
              case "dotLine":
               return Double(linePlotData[pointIndex])
              default:
                  return 0
              }
          }

          func label(atIndex pointIndex: Int) -> String {
            switch segmentFaceSaliva.selectedSegmentIndex {
            case 0:
                 return "\(myDatesForPlot1[pointIndex])"
            case 1:
                return "\(myDatesForPlot2[pointIndex])"
            default:
                return "ff"
            }
           // return "\(myDatesForPlot[pointIndex])"
          }

          func numberOfPoints() -> Int {
           return linePlotData.count
          }
       
       
       func hexStringToUIColor (hex:String) -> UIColor {
           var cString:String = hex.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()

           if (cString.hasPrefix("#")) {
               cString.remove(at: cString.startIndex)
           }

           if ((cString.count) != 6) {
               return UIColor.gray
           }

           var rgbValue:UInt64 = 0
           Scanner(string: cString).scanHexInt64(&rgbValue)

           return UIColor(
               red: CGFloat((rgbValue & 0xFF0000) >> 16) / 255.0,
               green: CGFloat((rgbValue & 0x00FF00) >> 8) / 255.0,
               blue: CGFloat(rgbValue & 0x0000FF) / 255.0,
               alpha: CGFloat(1.0)
           )
       }
}

extension GraphViewController: UIPickerViewDelegate, UIPickerViewDataSource{
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        pickerData.count
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return pickerData[row]
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        // face
        if segmentFaceSaliva.selectedSegmentIndex == 0 {
            switch row {
            case 0:
                linePlotData = [3,3,3,3.5,5,5.55,4,4.5,6]
            case 1:
                linePlotData = [4,4.5,6,3.5,5,5.55,4,4.5,6]
            case 2:
                linePlotData = [3.5,4.2,4,4.5,6,5.55,4,4.5,6]
            default:
                break
                
            }
        }
        
        //saliva
        
        if segmentFaceSaliva.selectedSegmentIndex == 1 {
            switch row {
                       case 0:
                           linePlotData = [4,4.5,6,3.5,5,5.55,4,4.5,6]
                       case 1:
                           linePlotData = [5,5.55,4,4.5,6]
                       case 2:
                           linePlotData = [3.5,4.2,5,5,5.55,4,4.5,6]
                       default:
                           break
                           
                       }
        }
        
        
        setUpGraph()
    }
    
    
    
    func convertToDate() -> [String]{
        let dates =  datesData
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd"
        dateFormatter.calendar = Calendar(identifier: .iso8601)
        var dateObjects = dates.flatMap { dateFormatter.date(from: $0) }
        dateObjects = dateObjects.sorted(by: {$0.timeIntervalSince1970 < $1.timeIntervalSince1970})
        var resultArr = [String]()
        for i in dateObjects {
            dateFormatter.dateFormat = "MM"
            let month = dateFormatter.string(from: i)
            dateFormatter.dateFormat = "dd"
            let day = dateFormatter.string(from: i)
            resultArr.append("\(day).\(month)")
        }
        
        return resultArr
    }
    
    func getForDay () -> Int? {
        let date = Date()
        let calendar = Calendar.current
        let components = calendar.dateComponents([.year, .month, .day], from: date)
        let day = components.day
        
//        for myDatesForPlot {
//            if
//        }
        
        return day
    }
    
    
}

extension GraphViewController {
    func getFaceMeasFromBack() {
        NetworkService.shared.getFacePhMeasures { [weak self] (result) in
            switch result {
            case .success(let measureArr):
                //  self?.marr = measureArr
                var resultForPlot = [Double]()
                var resultDate = [String]()
                globalLinePlotData = measureArr
                let group = DispatchGroup()
                group.enter()
                for i in measureArr{
                    resultForPlot.append(i.phFaceMeasure)
                    resultDate.append(i.measureDate)
                }
                self?.linePlotData = resultForPlot
                print(resultForPlot)
                self?.facePhs = resultForPlot
                self?.datesData = resultDate
                self?.setUpGraph()
                self?.myDatesForPlot1 = self?.convertToDate() ?? []
                
            case .failure(let error):
                self?.showAlert(alertText: error.description, alertAction: "ok", handler: nil)
            }
        }
    }
    
    
    func getSalivaMeasFromBack() {
        NetworkService.shared.getSalivaPhMeasures { [weak self] (result) in
            switch result {
             case .success(let measureArr):
                           //  self?.marr = measureArr
                           var resultForPlot = [Double]()
                           var resultDate = [String]()
                           globalLinePlotDataSaliva = measureArr
                           let group = DispatchGroup()
                           group.enter()
                           for i in measureArr{
                               resultForPlot.append(i.phSalivaMeasure)
                               resultDate.append(i.measureDate)
                           }
                          self?.linePlotData = resultForPlot
                           self?.datesData = resultDate
                           self?.salivaPhs = resultForPlot
                           //self?.setUpGraph()
                           self?.myDatesForPlot2 = self?.convertToDate() ?? []
                           
                       case .failure(let error):
                           self?.showAlert(alertText: error.description, alertAction: "ok", handler: nil)
            }
        }
    }
    
   
}
