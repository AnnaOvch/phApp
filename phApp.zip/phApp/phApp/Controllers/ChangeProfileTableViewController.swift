//
//  ChangeProfileTableViewController.swift
//  phApp
//
//  Created by Анна on 03.06.2020.
//  Copyright © 2020 anna. All rights reserved.
//

import UIKit

class ChangeProfileTableViewController: UITableViewController, Validatings {
    
    @IBOutlet weak var oldValueTextField: UITextField!
    @IBOutlet weak var newValueTextField: UITextField!
    
    var oldValue: String?
    var editingThing: Changings?
    var firstHeader: String?
    var secondHeader: String?
    var userBeforeChanging: User?
    weak var delegate: ChangeProtocol?
    
    let activityView = UIActivityIndicatorView(style: .medium)
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setUpHeaders()
        tableView.allowsSelection = false
        tableView.backgroundColor = hexStringToUIColor(hex: "#d1c0df")


    }

    @IBAction func saveButton(_ sender: Any) {
        if newValueTextField.text?.isEmpty == false {
            switch editingThing {
            case .email:
                let checkMail = validateEmail(candidate: newValueTextField.text!)
                if checkMail == true {
                    let user = User(email: newValueTextField.text!, firstName: userBeforeChanging?.firstName, lastName: userBeforeChanging?.lastName)
                    showActivityIndicatory(actView: activityView)
                    NetworkService.shared.changeUser(user: user) { [weak self](result) in
                        switch result {
                        case .success(let user):
                            self?.hideActivityIndicator(actView: self!.activityView)
                            globalMainUser?.email = user.email
                            self?.showAlert(alertText: "Email has been changed successfully", alertAction: "ok", handler: { (action) in
                                self?.navigationController?.popViewController(animated: true)
                            })
                        case .failure(let error):
                            self?.hideActivityIndicator(actView: self!.activityView)
                            self?.showAlert(alertText: error.description, alertAction: "ok", handler: nil)
                        }
                    }
                } else {
                    self.showAlert(alertText: "Invalid emal", alertAction: "ok", handler: nil)
                }
            case .firstName:
                let checkName = validateName(candidate: newValueTextField.text!)
                if checkName == true {
                    let user = User(email: userBeforeChanging?.email, firstName: newValueTextField.text!, lastName: userBeforeChanging?.lastName)
                    showActivityIndicatory(actView: activityView)
                    NetworkService.shared.changeUser(user: user) { [weak self](result) in
                        switch result {
                        case .success(let user):
                            self?.hideActivityIndicator(actView: self!.activityView)
                            globalMainUser?.firstName = user.firstName
                            self?.showAlert(alertText: "First name has been changed successfully", alertAction: "ok", handler: { (action) in
                                self?.navigationController?.popViewController(animated: true)
                            })
                        case .failure(let error):
                            self?.hideActivityIndicator(actView: self!.activityView)
                            self?.showAlert(alertText: error.description, alertAction: "ok", handler: nil)
                        }
                    }
                } else {
                    self.showAlert(alertText: "Invalid first name", alertAction: "ok", handler: nil)
                }
            case .lastName:
                print("last name")
                let checkLastName = validateName(candidate: newValueTextField.text!)
                if checkLastName == true {
                    print("true checkLastName")
                    let user = User(email: userBeforeChanging!.email, firstName: userBeforeChanging?.firstName, lastName: newValueTextField.text!)
                    showActivityIndicatory(actView: activityView)
                    NetworkService.shared.changeUser(user: user) {[weak self] (result) in
                        print("chhhh")
                        switch result {
                        case .success(let user):
                            self?.hideActivityIndicator(actView: self!.activityView)
                            globalMainUser?.lastName = user.lastName
                            self?.showAlert(alertText: "Last name has been changed successfully", alertAction: "ok", handler: { (action) in
                                self?.navigationController?.popViewController(animated: true)
                            })
                        case .failure(let error):
                            self?.hideActivityIndicator(actView: self!.activityView)
                            self?.showAlert(alertText: error.description, alertAction: "ok", handler: nil)
                        }
                        
                        
                    }
                    
                } else {
                    self.hideActivityIndicator(actView: self.activityView)
                    self.showAlert(alertText: "Invalid last name", alertAction: "ok", handler: nil)
                }
                
            case .password:
                let checkPassword = validatePassword(candidate: newValueTextField.text!)
                guard let old =  oldValueTextField.text else {
                    self.showAlert(alertText: "Enter old password", alertAction: "ok", handler: nil)
                    return
                }
                guard  globalPassword == old else {
                    self.showAlert(alertText: "Old password is incorrect", alertAction: "ok", handler: nil)
                    return
                }
                if checkPassword  == true {
                    showActivityIndicatory(actView: activityView)
                    NetworkService.shared.changePassword(password: newValueTextField.text!) { [weak self] (result) in
                        switch result {
                        case .success(let user):
                            self?.hideActivityIndicator(actView: self!.activityView)
                            globalMainUser?.password = user.password
                            globalPassword = self?.newValueTextField.text!
                            self?.showAlert(alertText: "Password has been changed successfully", alertAction: "ok", handler: { (action) in
                                self?.navigationController?.popViewController(animated: true)
                            })
                        case .failure(let error):
                            self?.hideActivityIndicator(actView: self!.activityView)
                            self?.showAlert(alertText: error.description, alertAction: "ok", handler: nil)
                        }
                    }
                } else {
                     self.hideActivityIndicator(actView: self.activityView)
                    self.showAlert(alertText: "Invalid new password", alertAction: "ok", handler: nil)
                }
                
            case .none:
                return
            }
        }
        else {
            self.showAlert(alertText: "Enter new \(editingThing!.rawValue) in field", alertAction: "ok", handler: nil)
        }
        
    }
    
   
    override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        switch section {
        case 0:
            return firstHeader
        case 1:
            return secondHeader
        default:
            break
        }
        return nil
    }
}
extension ChangeProfileTableViewController {
    func setUpHeaders() {
        if let headerForNab = editingThing{
            navigationItem.title = "Editing \(headerForNab.rawValue)"
        }
        
        if editingThing == Changings.password {
            self.oldValueTextField.isEnabled = true
        } else {
            self.oldValueTextField.isEnabled = false
        }
        switch editingThing {
        case .email:
            self.oldValueTextField.text = globalMainUser?.email
        case .lastName:
            guard let mainuser = globalMainUser else {return}
            self.oldValueTextField.text = mainuser.lastName ?? "No last name"
        case .firstName:
             guard let mainuser = globalMainUser else {return}
            self.oldValueTextField.text = mainuser.firstName ?? "No first name"
        default:
            break
        }
       }
    
    func hexStringToUIColor (hex:String) -> UIColor {
           var cString:String = hex.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()

           if (cString.hasPrefix("#")) {
               cString.remove(at: cString.startIndex)
           }

           if ((cString.count) != 6) {
               return UIColor.gray
           }

           var rgbValue:UInt64 = 0
           Scanner(string: cString).scanHexInt64(&rgbValue)

           return UIColor(
               red: CGFloat((rgbValue & 0xFF0000) >> 16) / 255.0,
               green: CGFloat((rgbValue & 0x00FF00) >> 8) / 255.0,
               blue: CGFloat(rgbValue & 0x0000FF) / 255.0,
               alpha: CGFloat(1.0)
           )
       }
}
protocol  ChangeProtocol: class {
    func saveTapped()
}
