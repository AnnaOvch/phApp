//
//  Extension.swift
//  phApp
//
//  Created by Анна on 03.06.2020.
//  Copyright © 2020 anna. All rights reserved.
//

import UIKit
extension UIViewController {
    
func showAlert(alertText : String, alertAction : String?, handler:((UIAlertAction) -> Void)?) {
        var completion: ((UIAlertAction) -> Void)? = nil
    
        if let handler = handler {
            completion = handler
        }
        let alert = UIAlertController(title: alertText, message: nil, preferredStyle: .alert)
        if let action = alertAction {
            alert.addAction(UIAlertAction(title: action, style: .default, handler: completion))
        }
        
        self.present(alert, animated: true, completion: nil)
        
    }
    
    
    func showActivityIndicatory(actView:UIActivityIndicatorView) {
         for subview in view.subviews where !(view is UIActivityIndicatorView) {
             subview.isHidden = true
         }
          actView.center = self.view.center
          actView.startAnimating()
          self.view.addSubview(actView)
      }
    func hideActivityIndicator(actView:UIActivityIndicatorView) {
          for subview in view.subviews where !(view is UIActivityIndicatorView) {
              subview.isHidden = false
          }
          actView.isHidden = true
          actView.stopAnimating()
          
      }
    
    func dismissKey()
    {
    let tap: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(UIViewController.dismissKeyboard))
        view.addGestureRecognizer(tap)
    }
    
    @objc func dismissKeyboard()
    {
    view.endEditing(true)
    }


}
